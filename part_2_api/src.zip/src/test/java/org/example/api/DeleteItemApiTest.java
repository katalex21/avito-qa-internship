package org.example.api;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.example.base.BaseApiTest;
import org.example.builders.ItemRequestBuilder;
import org.example.client.ItemApiClient;
import org.example.validators.ResponseValidator;
import org.junit.jupiter.api.Test;

import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DeleteItemApiTest extends BaseApiTest {
    
    private final ItemApiClient apiClient = new ItemApiClient();
    
    @Test
    public void testDeleteItemById_Success() {
        String itemId = apiClient.createItemAndGetId(ItemRequestBuilder.valid().build());
        
        Response response = apiClient.deleteItemById(itemId);
        response.then().statusCode(200);
    }
    
    @Test
    public void testDeleteItemById_BadRequest() {
        Response response = apiClient.deleteItemById("invalid-id-format");
        response.then()
                .statusCode(400)
                .body("status", notNullValue())
                .body("result", notNullValue());
    }
    
    @Test
    public void testDeleteItemById_NotFound() {
        Response response = apiClient.deleteItemById("non-existent-id-12345");
        
        assertTrue(response.getStatusCode() == 400 || response.getStatusCode() == 404,
                "Expected 400 or 404, but got " + response.getStatusCode());
        
        if (response.getStatusCode() == 404 || response.getStatusCode() == 400) {
            ResponseValidator.validateErrorResponse(response);
        }
    }
    
    @Test
    public void testDeleteItemById_ServerError() {
        Response response = RestAssured.given()
                .accept(ContentType.JSON)
                .when()
                .delete("/api/2/item/");
        
        assertTrue(response.getStatusCode() >= 400 && response.getStatusCode() < 600,
                "Expected error status code, but got " + response.getStatusCode());
        
        if (response.getStatusCode() == 500) {
            ResponseValidator.validateErrorResponse(response);
        }
    }
}

