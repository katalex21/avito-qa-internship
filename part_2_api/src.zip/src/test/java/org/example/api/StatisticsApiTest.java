package org.example.api;

import org.example.base.BaseApiTest;
import org.example.builders.ItemRequestBuilder;
import org.example.client.ItemApiClient;
import org.example.models.Statistics;
import org.example.validators.ResponseValidator;
import org.junit.jupiter.api.Test;

public class StatisticsApiTest extends BaseApiTest {
    
    private final ItemApiClient apiClient = new ItemApiClient();
    
    @Test
    public void testGetStatisticByIdV1_Success() {
        String itemId = apiClient.createItemAndGetId(ItemRequestBuilder.valid().build());
        
        Statistics[] statistics = apiClient.getStatisticByIdV1AsArray(itemId);
        ResponseValidator.validateStatisticsArray(statistics);
    }
    
    @Test
    public void testGetStatisticByIdV2_Success() {
        String itemId = apiClient.createItemAndGetId(ItemRequestBuilder.valid().build());
        
        Statistics[] statistics = apiClient.getStatisticByIdV2AsArray(itemId);
        ResponseValidator.validateStatisticsArray(statistics);
    }
}

