package org.example.api;

import io.restassured.response.Response;
import org.example.base.BaseApiTest;
import org.example.builders.ItemRequestBuilder;
import org.example.client.ItemApiClient;
import org.example.models.CreateItemResponse;
import org.example.models.ItemRequest;
import org.example.validators.ResponseValidator;
import org.junit.jupiter.api.Test;

import static org.hamcrest.Matchers.notNullValue;

public class CreateItemApiTest extends BaseApiTest {
    
    private final ItemApiClient apiClient = new ItemApiClient();
    
    @Test
    public void testCreateItem_Success() {
        ItemRequest request = ItemRequestBuilder.valid().build();
        
        Response response = apiClient.createItem(request);
        response.then().statusCode(200);
        
        CreateItemResponse createdItem = response.as(CreateItemResponse.class);
        ResponseValidator.validateCreateItemResponse(createdItem, request);
    }
    
    @Test
    public void testCreateItem_BadRequest() {
        ItemRequest invalidRequest = ItemRequestBuilder.invalid().build();
        
        Response response = apiClient.createItem(invalidRequest);
        response.then()
                .statusCode(400)
                .body("status", notNullValue())
                .body("result", notNullValue());
    }
}

