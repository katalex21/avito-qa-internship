package org.example.api;

import org.example.base.BaseApiTest;
import org.example.builders.ItemRequestBuilder;
import org.example.client.ItemApiClient;
import org.example.models.ItemRequest;
import org.example.models.ItemResponse;
import org.example.validators.ResponseValidator;
import org.example.utils.TestUtils;
import org.junit.jupiter.api.Test;

public class GetItemApiTest extends BaseApiTest {
    
    private final ItemApiClient apiClient = new ItemApiClient();
    
    @Test
    public void testGetItemById_Success() {
        ItemRequest request = ItemRequestBuilder.valid().build();
        String itemId = apiClient.createItemAndGetId(request);
        
        ItemResponse[] items = apiClient.getItemByIdAsArray(itemId);
        ResponseValidator.validateItemResponseArray(items);
    }
    
    @Test
    public void testGetItemsBySellerId_Success() {
        Integer sellerId = TestUtils.generateUniqueSellerId();
        
        ItemRequest request1 = ItemRequestBuilder.valid()
                .withSellerId(sellerId)
                .withName("Item 1")
                .withPrice(1000)
                .withStatistics(10, 100, 5)
                .build();
        
        ItemRequest request2 = ItemRequestBuilder.valid()
                .withSellerId(sellerId)
                .withName("Item 2")
                .withPrice(2000)
                .withStatistics(20, 200, 10)
                .build();
        
        apiClient.createItem(request1).then().statusCode(200);
        apiClient.createItem(request2).then().statusCode(200);
        
        ItemResponse[] items = apiClient.getItemsBySellerIdAsArray(sellerId);
        ResponseValidator.validateItemResponseArrayForSeller(items, sellerId);
    }
}

