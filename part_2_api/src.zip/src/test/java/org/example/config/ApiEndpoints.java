package org.example.config;

public final class ApiEndpoints {
    
    private ApiEndpoints() {
        throw new UnsupportedOperationException("Utility class");
    }

    public static final String API_V1_ITEM = "/api/1/item";
    public static final String API_V1_ITEM_BY_ID = "/api/1/item/{id}";
    public static final String API_V1_STATISTIC_BY_ID = "/api/1/statistic/{id}";
    public static final String API_V1_ITEMS_BY_SELLER_ID = "/api/1/{sellerID}/item";

    public static final String API_V2_ITEM_BY_ID = "/api/2/item/{id}";
    public static final String API_V2_STATISTIC_BY_ID = "/api/2/statistic/{id}";
    
    public static String getItemByIdPath(String id) {
        return API_V1_ITEM_BY_ID.replace("{id}", id);
    }
    
    public static String getStatisticByIdPath(String id) {
        return API_V1_STATISTIC_BY_ID.replace("{id}", id);
    }
    
    public static String getItemsBySellerIdPath(Integer sellerId) {
        return API_V1_ITEMS_BY_SELLER_ID.replace("{sellerID}", String.valueOf(sellerId));
    }
    
    public static String getV2ItemByIdPath(String id) {
        return API_V2_ITEM_BY_ID.replace("{id}", id);
    }
    
    public static String getV2StatisticByIdPath(String id) {
        return API_V2_STATISTIC_BY_ID.replace("{id}", id);
    }
}

