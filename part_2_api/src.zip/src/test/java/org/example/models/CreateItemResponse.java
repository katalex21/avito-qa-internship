package org.example.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Objects;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreateItemResponse {
    private String id;
    private Integer sellerId;
    private String name;
    private Integer price;
    private Statistics statistics;
    private String createdAt;
    private String status;

    public CreateItemResponse() {
    }

    public CreateItemResponse(String id, Integer sellerId, String name, Integer price, Statistics statistics, String createdAt) {
        this.id = id;
        this.sellerId = sellerId;
        this.name = name;
        this.price = price;
        this.statistics = statistics;
        this.createdAt = createdAt;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getSellerId() {
        return sellerId;
    }

    public void setSellerId(Integer sellerId) {
        this.sellerId = sellerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Statistics getStatistics() {
        return statistics;
    }

    public void setStatistics(Statistics statistics) {
        this.statistics = statistics;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
        if (status != null && status.contains(" - ")) {
            String[] parts = status.split(" - ");
            if (parts.length > 1) {
                this.id = parts[parts.length - 1].trim();
            }
        }
    }
    
    public String extractIdFromStatus() {
        if (status != null && status.contains(" - ")) {
            String[] parts = status.split(" - ");
            if (parts.length > 1) {
                return parts[parts.length - 1].trim();
            }
        }
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CreateItemResponse that = (CreateItemResponse) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(sellerId, that.sellerId) &&
                Objects.equals(name, that.name) &&
                Objects.equals(price, that.price) &&
                Objects.equals(statistics, that.statistics) &&
                Objects.equals(createdAt, that.createdAt) &&
                Objects.equals(status, that.status);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, sellerId, name, price, statistics, createdAt, status);
    }

    @Override
    public String toString() {
        return "CreateItemResponse{" +
                "id='" + id + '\'' +
                ", sellerId=" + sellerId +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", statistics=" + statistics +
                ", createdAt='" + createdAt + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}

