package org.example.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Objects;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Statistics {
    private Integer likes;
    private Integer viewCount;
    private Integer contacts;

    public Statistics() {
    }

    public Statistics(Integer likes, Integer viewCount, Integer contacts) {
        this.likes = likes;
        this.viewCount = viewCount;
        this.contacts = contacts;
    }

    public Integer getLikes() {
        return likes;
    }

    public void setLikes(Integer likes) {
        this.likes = likes;
    }

    public Integer getViewCount() {
        return viewCount;
    }

    public void setViewCount(Integer viewCount) {
        this.viewCount = viewCount;
    }

    public Integer getContacts() {
        return contacts;
    }

    public void setContacts(Integer contacts) {
        this.contacts = contacts;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Statistics that = (Statistics) o;
        return Objects.equals(likes, that.likes) &&
                Objects.equals(viewCount, that.viewCount) &&
                Objects.equals(contacts, that.contacts);
    }

    @Override
    public int hashCode() {
        return Objects.hash(likes, viewCount, contacts);
    }

    @Override
    public String toString() {
        return "Statistics{" +
                "likes=" + likes +
                ", viewCount=" + viewCount +
                ", contacts=" + contacts +
                '}';
    }
}

