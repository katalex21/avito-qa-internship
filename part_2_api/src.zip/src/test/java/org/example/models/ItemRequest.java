package org.example.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

public class ItemRequest {
    @JsonProperty("sellerID")
    private Integer sellerID;
    private String name;
    private Integer price;
    private Statistics statistics;

    public ItemRequest() {
    }

    public ItemRequest(Integer sellerID, String name, Integer price, Statistics statistics) {
        this.sellerID = sellerID;
        this.name = name;
        this.price = price;
        this.statistics = statistics;
    }

    public Integer getSellerID() {
        return sellerID;
    }

    public void setSellerID(Integer sellerID) {
        this.sellerID = sellerID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Statistics getStatistics() {
        return statistics;
    }

    public void setStatistics(Statistics statistics) {
        this.statistics = statistics;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemRequest that = (ItemRequest) o;
        return Objects.equals(sellerID, that.sellerID) &&
                Objects.equals(name, that.name) &&
                Objects.equals(price, that.price) &&
                Objects.equals(statistics, that.statistics);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sellerID, name, price, statistics);
    }

    @Override
    public String toString() {
        return "ItemRequest{" +
                "sellerID=" + sellerID +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", statistics=" + statistics +
                '}';
    }
}

