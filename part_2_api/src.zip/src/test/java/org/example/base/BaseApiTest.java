package org.example.base;

import io.restassured.RestAssured;
import io.restassured.config.LogConfig;
import org.example.utils.TestUtils;
import org.junit.jupiter.api.BeforeAll;


public abstract class BaseApiTest {
    
    @BeforeAll
    public static void setup() {
        TestUtils.setBaseUri();
        // Логирование при ошибках валидации
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
        // Включить pretty printing для логов
        RestAssured.config = RestAssured.config()
                .logConfig(LogConfig.logConfig()
                        .enableLoggingOfRequestAndResponseIfValidationFails()
                        .enablePrettyPrinting(true));
    }
}

