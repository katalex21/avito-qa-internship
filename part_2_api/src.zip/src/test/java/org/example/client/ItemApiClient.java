package org.example.client;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.example.config.ApiEndpoints;
import org.example.models.CreateItemResponse;
import org.example.models.ItemRequest;
import org.example.models.ItemResponse;
import org.example.models.Statistics;

import static io.restassured.RestAssured.given;


public class ItemApiClient {

    public Response createItem(ItemRequest request) {
        return given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .body(request)
                .log().all()
                .when()
                .post(ApiEndpoints.API_V1_ITEM)
                .then()
                .log().all()
                .extract()
                .response();
    }

    public String createItemAndGetId(ItemRequest request) {
        Response response = createItem(request);
        response.then()
                .statusCode(200);
        
        CreateItemResponse createdItem = response.as(CreateItemResponse.class);
        if (createdItem.getId() == null) {
            CreateItemResponse[] items = response.as(CreateItemResponse[].class);
            if (items != null && items.length > 0) {
                createdItem = items[0];
            }
        }
        
        String itemId = createdItem.getId();
        if (itemId == null && createdItem.getStatus() != null) {
            itemId = createdItem.extractIdFromStatus();
        }
        
        if (itemId == null) {
            throw new IllegalStateException("Не удалось достать ID: " + response.getBody().asString());
        }
        
        return itemId;
    }

    public Response getItemById(String id) {
        return given()
                .accept(ContentType.JSON)
                .log().all()
                .when()
                .get(ApiEndpoints.API_V1_ITEM_BY_ID, id)
                .then()
                .log().all()
                .extract()
                .response();
    }

    public ItemResponse[] getItemByIdAsArray(String id) {
        Response response = getItemById(id);
        response.then().statusCode(200);
        return response.as(ItemResponse[].class);
    }


    public Response deleteItemById(String id) {
        return given()
                .accept(ContentType.JSON)
                .log().all()
                .when()
                .delete(ApiEndpoints.API_V2_ITEM_BY_ID, id)
                .then()
                .log().all()
                .extract()
                .response();
    }

    public Response getStatisticByIdV1(String id) {
        return given()
                .accept(ContentType.JSON)
                .log().all()
                .when()
                .get(ApiEndpoints.API_V1_STATISTIC_BY_ID, id)
                .then()
                .log().all()
                .extract()
                .response();
    }

    public Statistics[] getStatisticByIdV1AsArray(String id) {
        Response response = getStatisticByIdV1(id);
        response.then().statusCode(200);
        return response.as(Statistics[].class);
    }

    public Response getStatisticByIdV2(String id) {
        return given()
                .accept(ContentType.JSON)
                .log().all()
                .when()
                .get(ApiEndpoints.API_V2_STATISTIC_BY_ID, id)
                .then()
                .log().all()
                .extract()
                .response();
    }

    public Statistics[] getStatisticByIdV2AsArray(String id) {
        Response response = getStatisticByIdV2(id);
        response.then().statusCode(200);
        return response.as(Statistics[].class);
    }

    public Response getItemsBySellerId(Integer sellerId) {
        return given()
                .accept(ContentType.JSON)
                .log().all()
                .when()
                .get(ApiEndpoints.API_V1_ITEMS_BY_SELLER_ID, sellerId)
                .then()
                .log().all()
                .extract()
                .response();
    }

    public ItemResponse[] getItemsBySellerIdAsArray(Integer sellerId) {
        Response response = getItemsBySellerId(sellerId);
        response.then().statusCode(200);
        return response.as(ItemResponse[].class);
    }
}

