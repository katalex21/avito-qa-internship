package org.example.builders;

import org.example.models.ItemRequest;
import org.example.models.Statistics;
import org.example.utils.TestUtils;

public class ItemRequestBuilder {
    private Integer sellerId;
    private String name;
    private Integer price;
    private Statistics statistics;
    
    public ItemRequestBuilder() {
        this.sellerId = TestUtils.generateUniqueSellerId();
        this.name = "Test Item";
        this.price = 1000;
        this.statistics = new Statistics(10, 100, 5);
    }
    
    public ItemRequestBuilder withSellerId(Integer sellerId) {
        this.sellerId = sellerId;
        return this;
    }
    
    public ItemRequestBuilder withName(String name) {
        this.name = name;
        return this;
    }
    
    public ItemRequestBuilder withPrice(Integer price) {
        this.price = price;
        return this;
    }
    
    public ItemRequestBuilder withStatistics(Statistics statistics) {
        this.statistics = statistics;
        return this;
    }
    
    public ItemRequestBuilder withStatistics(Integer likes, Integer viewCount, Integer contacts) {
        this.statistics = new Statistics(likes, viewCount, contacts);
        return this;
    }
    
    public ItemRequest build() {
        return new ItemRequest(sellerId, name, price, statistics);
    }

    public static ItemRequestBuilder valid() {
        return new ItemRequestBuilder();
    }
    

    public static ItemRequestBuilder invalid() {
        return new ItemRequestBuilder()
                .withSellerId(null)
                .withName(null)
                .withPrice(null)
                .withStatistics(null);
    }
}

