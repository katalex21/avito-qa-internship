package org.example.utils;

import java.util.concurrent.ThreadLocalRandom;

import static io.restassured.RestAssured.baseURI;


public final class TestUtils {
    
    private static final String BASE_URL = "https://qa-internship.avito.com";
    private static final int MIN_SELLER_ID = 111111;
    private static final int MAX_SELLER_ID = 999999;
    
    private TestUtils() {
        throw new UnsupportedOperationException("Utility class");
    }

    public static String getBaseUrl() {
        return BASE_URL;
    }

    public static void setBaseUri() {
        baseURI = BASE_URL;
    }

    public static int generateUniqueSellerId() {
        return ThreadLocalRandom.current().nextInt(MIN_SELLER_ID, MAX_SELLER_ID + 1);
    }
}
