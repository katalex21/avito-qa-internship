package org.example.validators;

import io.restassured.response.Response;
import org.example.models.CreateItemResponse;
import org.example.models.ItemRequest;
import org.example.models.ItemResponse;
import org.example.models.Statistics;

import static org.junit.jupiter.api.Assertions.*;

public final class ResponseValidator {
    
    private ResponseValidator() {
        throw new UnsupportedOperationException("Utility class");
    }

    public static void validateCreateItemResponse(CreateItemResponse response, ItemRequest request) {
        assertNotNull(response, "CreateItemResponse should not be null");
        
        String itemId = response.getId();
        if (itemId == null && response.getStatus() != null) {
            itemId = response.extractIdFromStatus();
        }
        
        assertNotNull(itemId, "Item ID should not be null");
        
        if (response.getStatus() != null) {
            assertNotNull(response.getStatus(), "Status should not be null");
        } else {
            assertNotNull(response.getSellerId(), "SellerId should not be null");
            assertEquals(request.getSellerID(), response.getSellerId(), "SellerId should match request");
            assertEquals(request.getName(), response.getName(), "Name should match request");
            assertEquals(request.getPrice(), response.getPrice(), "Price should match request");
            assertNotNull(response.getStatistics(), "Statistics should not be null");
            assertNotNull(response.getCreatedAt(), "CreatedAt should not be null");
        }
    }

    public static void validateItemResponseArray(ItemResponse[] items) {
        assertNotNull(items, "Items array should not be null");
        assertTrue(items.length > 0, "Items array should not be empty");
        
        for (ItemResponse item : items) {
            validateItemResponse(item);
        }
    }

    public static void validateItemResponse(ItemResponse item) {
        assertNotNull(item, "Item should not be null");
        assertNotNull(item.getId(), "Item ID should not be null");
        assertNotNull(item.getSellerId(), "Item sellerId should not be null");
        assertNotNull(item.getName(), "Item name should not be null");
        assertNotNull(item.getPrice(), "Item price should not be null");
        assertNotNull(item.getStatistics(), "Item statistics should not be null");
        assertNotNull(item.getCreatedAt(), "Item createdAt should not be null");
    }

    public static void validateItemResponseArrayForSeller(ItemResponse[] items, Integer sellerId) {
        validateItemResponseArray(items);
        assertTrue(items.length >= 1, "Should have at least one item for seller");
        
        for (ItemResponse item : items) {
            validateItemResponse(item);
            assertEquals(sellerId, item.getSellerId(), "All items should belong to the same seller");
        }
    }

    public static void validateStatisticsArray(Statistics[] statistics) {
        assertNotNull(statistics, "Statistics array should not be null");
        assertTrue(statistics.length > 0, "Statistics array should not be empty");
        
        for (Statistics stat : statistics) {
            validateStatistics(stat);
        }
    }

    public static void validateStatistics(Statistics stat) {
        assertNotNull(stat, "Statistics should not be null");
        assertNotNull(stat.getLikes(), "Likes should not be null");
        assertNotNull(stat.getViewCount(), "ViewCount should not be null");
        assertNotNull(stat.getContacts(), "Contacts should not be null");
    }

    public static void validateErrorResponse(Response response) {
        response.then()
                .body("status", org.hamcrest.Matchers.notNullValue())
                .body("result", org.hamcrest.Matchers.notNullValue());
    }
}

